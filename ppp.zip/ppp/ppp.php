<?php
/*
Plugin Name: WordPress Plugin Playground
Description: Demo WordPress Plugins
Version: 1.5.6
Author: Press Plugin Play
*/

// Inject URL data for JavaScript using wp_localize_script
add_action('admin_enqueue_scripts', function () {
    wp_enqueue_script('jquery'); // Enqueue jQuery if it's not already loaded
    wp_enqueue_script('ppp-enhanced-ui', plugin_dir_url(__FILE__) . 'ppp-enhanced-ui.js', array('jquery'), '1.5.6', true);
    wp_localize_script('ppp-enhanced-ui', 'ppp_data', [
        'pluginInstallUrl' => admin_url('plugin-install.php')
    ]);
});

// Add custom UI inline via admin_footer
add_action('admin_footer', 'ppp_add_custom_ui', 5);
function ppp_add_custom_ui() {
    $screen = get_current_screen();

    if ($screen && $screen->id === 'plugin-install') {
        ?>
        <style type="text/css">
            .plugin-install-php #plugin-filter {
                opacity: 0;
                transition: opacity 0.3s ease-in-out;
            }
            .wp-filter .search-form {
                display: none !important;
            }
        </style>
        <?php
    }
}
?>

