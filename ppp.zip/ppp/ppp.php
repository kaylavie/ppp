<?php
/*
Plugin Name: Demo WordPress Plugins
Description: Adds a "Try Demo" button to each plugin card in the WordPress admin dashboard, enhances search functionality, and provides personalized plugin recommendations.
Version: 1.5.4
Author: Press Plugin Play
*/

add_action('admin_head', 'ppp_add_custom_ui', 5); 
function ppp_add_custom_ui() {
    $screen = get_current_screen();
    if ($screen && $screen->id === 'plugin-install') {
        ?>
        <style type="text/css">
            #search-plugins,
            #search-submit,
            .wp-form.search-form,
            form.search-plugins {display: none !important;}
            .plugin-action-buttons {
                min-height: 50px;
            }
        </style>
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            const wpFilter = $('.wp-filter');
            function addTryDemoLinks() {
                $('.plugin-action-buttons .install-now').each(function() {
                    var installButton = $(this);
                    var slug = installButton.data('slug');

                    if (installButton.closest('ul.plugin-action-buttons').find('.try-demo-link').length === 0 && slug) {
                        var demoLink = $('<li class="try-demo-link"><a class="button" href="https://presspluginplay.com/' + slug + '" target="_blank" rel="noopener noreferrer">Try Demo</a></li>');
                        var demoWrapper = $('<div class="try-demo-wrapper"></div>').append(demoLink);
                        installButton.closest('ul.plugin-action-buttons').prepend(demoWrapper);
                    }
                });
            }
            function addCustomSearchForm() {
                $('#plugin-filter .search-form, form.search-plugins').remove();

                if (!$('#ppp-custom-search-form').length) {
                    var customSearchForm = $('<form id="ppp-custom-search-form" method="get" action="<?php echo admin_url('plugin-install.php'); ?>"></form>');
                    customSearchForm.append('<input type="hidden" name="tab" value="search">');
                    customSearchForm.append('<input type="hidden" name="type" value="term">');
                    customSearchForm.append('<input type="search" name="s" id="ppp-search-plugins" placeholder="Search Plugins..." style="width: 300px; margin-right: 5px;">');
                    customSearchForm.append('<input type="submit" id="ppp-search-submit" class="button" value="Search Plugins">');
                    wpFilter.append(customSearchForm);
                }
            }

            const observer = new MutationObserver((mutations) => {
                mutations.forEach((mutation) => {
                    if (mutation.addedNodes.length) {
                        addTryDemoLinks();  
                        addCustomSearchForm(); 
                    }
                });
            });

            observer.observe(document.body, {
                childList: true,
                subtree: true
            });
            addTryDemoLinks();
            addCustomSearchForm();
        });
        </script>
 	<?php
}}
?>

