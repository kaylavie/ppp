<?php
/*
Plugin Name: Demo WordPress Plugins
Description: Adds a "Try Demo" button to each plugin card in the WordPress admin dashboard, enhances search functionality, and provides personalized plugin recommendations.
Version: 1.5.0
Author: Press Plugin Play
*/

add_action('admin_head', 'ppp_add_custom_ui', 5); 
function ppp_add_custom_ui() {
    $screen = get_current_screen();
    if ($screen && $screen->id === 'plugin-install') {
        ?>
        <style type="text/css">#search-plugins { display: none;} #search-submit { display: none;}</style>
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            function addTryDemoLinks() {
                $('.plugin-action-buttons .install-now').each(function() {
                    var installButton = $(this);
                    var slug = installButton.data('slug');
                    if (installButton.closest('ul.plugin-action-buttons').find('.try-demo-link').length === 0 && slug) {
                        var demoLink = $('<li class="try-demo-link"><a class="button" href="https://presspluginplay.com/' + slug + '" target="_blank" rel="noopener noreferrer">Try Demo</a></li>');
                        installButton.closest('ul.plugin-action-buttons').prepend(demoLink);
                    }
                });
            }
            function addCustomSearchForm() {
                $('form.search-form').remove();
                var customSearchForm = $('<form id="ppp-custom-search-form" method="get" action="<?php echo admin_url('plugin-install.php'); ?>"></form>');
                customSearchForm.append('<input type="hidden" name="tab" value="search">');
                customSearchForm.append('<input type="hidden" name="type" value="term">');
                customSearchForm.append('<input type="search" name="s" id="ppp-search-plugins" placeholder="Search Plugins..." style="width: 300px; margin-right: 5px;">');
                customSearchForm.append('<input type="submit" id="ppp-search-submit" class="button" value="Search Plugins">');
                $('.wp-filter').append(customSearchForm);
            }
            addTryDemoLinks();
            addCustomSearchForm();
        });</script>
	<?php
    }
}



