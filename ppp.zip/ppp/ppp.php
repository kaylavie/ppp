<?php
/*
Plugin Name: Demo WordPress Plugins
Description: Adds a "Try Demo" button to each plugin card in the WordPress admin dashboard, enhances search functionality, and provides personalized plugin recommendations.
Version: 1.5.3
Author: Press Plugin Play
*/

add_action('admin_head', 'ppp_add_custom_ui', 5); // Run early to catch initial rendering

function ppp_add_custom_ui() {
    $screen = get_current_screen();

    if ($screen && $screen->id === 'plugin-install') {
        ?>
        <style type="text/css">
            /* Immediate hide of existing search input and button */
            #search-plugins,
            #search-submit,
            .wp-form.search-form,
            form.search-plugins {
                display: none !important;
            }

            /* Reserve space for plugin action buttons to reduce CLS */
            .plugin-action-buttons {
                min-height: 50px; /* Adjust this value if necessary */
            }
        </style>
        <script type="text/javascript">
        jQuery(document).ready(function($) {

            // Cached selectors
            const wpFilter = $('.wp-filter');
            const pluginFilterSearchForm = $('#plugin-filter .search-form');

            // Immediately hide existing search forms on load
            pluginFilterSearchForm.hide();
            $('form.search-plugins').hide();

            // Function to add "Try Demo" links
            function addTryDemoLinks() {
                $('.plugin-action-buttons .install-now').each(function() {
                    var installButton = $(this);
                    var slug = installButton.data('slug');

                    // Check if the "Try Demo" link already exists to avoid duplicates
                    if (installButton.closest('ul.plugin-action-buttons').find('.try-demo-link').length === 0 && slug) {
                        // Create the new "Try Demo" link
                        var demoLink = $('<li class="try-demo-link"><a class="button" href="https://presspluginplay.com/' + slug + '" target="_blank" rel="noopener noreferrer">Try Demo</a></li>');

                        // Wrap in a div to minimize layout shifts
                        var demoWrapper = $('<div class="try-demo-wrapper"></div>').append(demoLink);

                        // Prepend the "Try Demo" link wrapper before the "Install Now" button
                        installButton.closest('ul.plugin-action-buttons').prepend(demoWrapper);
                    }
                });
            }

            // Function to create and insert the new search form
            function addCustomSearchForm() {
                // Remove the existing search form if it exists
                pluginFilterSearchForm.remove();
                $('form.search-plugins').remove();

                // Create a new search form if it does not exist
                if (!$('#ppp-custom-search-form').length) {
                    var customSearchForm = $('<form id="ppp-custom-search-form" method="get" action="<?php echo admin_url('plugin-install.php'); ?>"></form>');

                    // Add hidden input fields for required query parameters
                    customSearchForm.append('<input type="hidden" name="tab" value="search">');
                    customSearchForm.append('<input type="hidden" name="type" value="term">');

                    // Add the search input field
                    customSearchForm.append('<input type="search" name="s" id="ppp-search-plugins" placeholder="Search Plugins..." style="width: 300px; margin-right: 5px;">');

                    // Add the submit button
                    customSearchForm.append('<input type="submit" id="ppp-search-submit" class="button" value="Search Plugins">');

                    // Insert the custom search form into the page
                    wpFilter.append(customSearchForm);
                }
            }

            // Initial run with slight delay for smoother loading
            setTimeout(function() {
                addTryDemoLinks();
                addCustomSearchForm();
            }, 100); // Adjust delay as necessary

        });
        </script>
        <?php
    }
}


?>

