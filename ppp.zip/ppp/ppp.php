<?php
/*
Plugin Name: WordPress Plugin Playground
Description: Demo WordPress Plugins
Version: 1.5.6
Author: Press Plugin Play
*/

// Enqueue styles and scripts with lower priority
add_action('admin_enqueue_scripts', 'ppp_add_enhanced_ui_scripts', 5);
function ppp_add_enhanced_ui_scripts() {
    $screen = get_current_screen();

    if ($screen && $screen->id === 'plugin-install') {
        wp_enqueue_style('ppp-enhanced-ui', plugin_dir_url(__FILE__) . 'ppp-enhanced-ui.css', array(), '1.5.6');
        wp_enqueue_script('jquery');
        wp_enqueue_script('ppp-custom-filters', plugin_dir_url(__FILE__) . 'ppp-custom-filters.js', array('jquery'), '1.5.6', true);
    }
}

// Add custom UI inline via admin_footer
add_action('admin_footer', 'ppp_add_custom_ui', 5);
function ppp_add_custom_ui() {
    $screen = get_current_screen();

    if ($screen && $screen->id === 'plugin-install') {
        ?>
        <style type="text/css">
            /* Initially hide plugin area until fully loaded */
            .plugin-install-php #plugin-filter {
                opacity: 0;
                transition: opacity 0.3s ease-in-out;
            }
            /* Hide original search form */
            .wp-filter .search-form {
                display: none !important;
            }
        </style>

        <script type="text/javascript">
        (function($) {
            $(document).ready(function() {

                function log(message) {
                    if (window.ppp_debug) console.log('PPPlayground:', message);
                }

                // Add Try Demo Links
                function addTryDemoLinks() {
                    $('.plugin-action-buttons .install-now').each(function() {
                        var installButton = $(this);
                        var slug = installButton.data('slug');
                        if (!installButton.siblings('.try-demo-link').length && slug) {
                            var demoLink = $('<li class="try-demo-link"><a class="button" href="https://presspluginplay.com/' + slug + '" target="_blank" rel="noopener noreferrer">Try Demo</a></li>');
                            installButton.before(demoLink);
                            log('Added Try Demo link for slug: ' + slug);
                        }
                    });
                }

                // Add Custom Search Form
                function addCustomSearchForm() {
                    $('#ppp-custom-search-form').remove();
                    var customSearchForm = $('<form id="ppp-custom-search-form" method="get" action="<?php echo admin_url('plugin-install.php'); ?>"></form>');
                    customSearchForm.append('<input type="hidden" name="tab" value="search">');
                    customSearchForm.append('<input type="hidden" name="type" value="term">');
                    customSearchForm.append('<input type="search" name="s" placeholder="Search Plugins..." style="width: 300px; margin-right: 5px;">');
                    customSearchForm.append('<input type="submit" class="button" value="Search Plugins">');
                    $('.wp-filter').append(customSearchForm);
                    log('Added custom search form.');
                }

                // Hide original search form permanently
                function hideOriginalSearchForm() {
                    $('.wp-filter .search-form').remove();
                    log('Original search form removed.');
                }

                // Main function to insert UI elements
                function insertCustomUI() {
                    hideOriginalSearchForm();
                    addTryDemoLinks();
                    addCustomSearchForm();
                    $('#plugin-filter').css('opacity', '1'); // Reveal plugin area after custom UI is loaded
                    log('Inserted all custom UI elements.');
                }

                // Initialize custom UI insertion
                function initCustomUI() {
                    if ($('.filter-links').length && $('.plugin-action-buttons').length && $('.wp-filter').length) {
                        insertCustomUI();
                        log('Direct UI insertion on document load.');
                    } else {
                        var observer = new MutationObserver(function(mutations, obs) {
                            mutations.forEach(function(mutation) {
                                if (mutation.type === 'childList') {
                                    var target = $(mutation.target);
                                    if (target.find('.filter-links').length || target.hasClass('filter-links') ||
                                        target.find('.plugin-action-buttons').length || target.hasClass('plugin-action-buttons') ||
                                        target.find('.wp-filter').length || target.hasClass('wp-filter')) {
                                        if ($('.filter-links').length && $('.plugin-action-buttons').length && $('.wp-filter').length) {
                                            insertCustomUI();
                                            obs.disconnect();
                                            log('UI inserted via MutationObserver.');
                                        }
                                    }
                                }
                            });
                        });
                        observer.observe(document.body, { childList: true, subtree: true });
                        log('Started MutationObserver as backup.');
                    }
                }

                // Hide search form again after any AJAX updates
                $(document).ajaxComplete(function() {
                    hideOriginalSearchForm();
                });

                window.ppp_debug = true;
                initCustomUI();

            });
        })(jQuery);
        </script>
        <?php
    }
}
?>

