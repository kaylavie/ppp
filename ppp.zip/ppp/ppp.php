<?php
/*
Plugin Name: Demo WordPress Plugins
Description: Try a WordPress Plugin Demo.
Version: 1.5.0
Author: Press Plugin Play
*/

//include 'ppp-my-favorites.php';
add_action('admin_enqueue_scripts', 'ppp_add_enhanced_ui_scripts', 5); // Lower priority to load earlier
function ppp_add_enhanced_ui_scripts() {
    $screen = get_current_screen();

    // Only load scripts and styles on plugin installation page
    if ($screen && $screen->id === 'plugin-install') {
        wp_enqueue_style('ppp-enhanced-ui', plugin_dir_url(__FILE__) . 'ppp-enhanced-ui.css', array(), '1.5.0');
        wp_enqueue_script('jquery');
        wp_enqueue_script('ppp-custom-filters', plugin_dir_url(__FILE__) . 'ppp-custom-filters.js', array('jquery'), '1.5.0', true);

        
    }
}

add_action('admin_footer', 'ppp_add_custom_ui', 5); // Run earlier to catch initial rendering

function ppp_add_custom_ui() {
    $screen = get_current_screen();

    if ($screen && $screen->id === 'plugin-install') {
        ?>
        <style type="text/css">
            /* Hide the existing search input */
            #search-plugins {
                display: none;
            }
            /* Hide the existing search button if it exists */
            #search-submit {
                display: none;
            }
        </style>
        <script type="text/javascript">
        jQuery(document).ready(function($) {

            

            // Function to create and insert the new search form
            function addCustomSearchForm() {
                // Remove the existing search form
                $('#plugin-filter .search-form').remove();

                // Create a new search form
                var customSearchForm = $('<form id="ppp-custom-search-form" method="get" action="<?php echo admin_url('plugin-install.php'); ?>"></form>');

                // Add hidden input fields for required query parameters
                customSearchForm.append('<input type="hidden" name="tab" value="search">');
                customSearchForm.append('<input type="hidden" name="type" value="term">');

                // Add the search input field
                customSearchForm.append('<input type="search" name="s" id="ppp-search-plugins" placeholder="Search Plugins..." style="width: 300px; margin-right: 5px;">');

                // Add the submit button
                customSearchForm.append('<input type="submit" id="ppp-search-submit" class="button" value="Search Plugins">');

                // Insert the custom search form into the page
                $('.wp-filter').append(customSearchForm);
            }

            // Initial run
            //addRecommendationButton();
            addTryDemoLinks();
            addCustomSearchForm();

        });
        </script>
        <?php
    }
}



