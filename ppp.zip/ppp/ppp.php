<?php
/*
Plugin Name: Demo WordPress Plugins
Description: Adds a "Try Demo" button to each plugin card in the WordPress admin dashboard, enhances search functionality, and provides personalized plugin recommendations.
Version: 1.5.0
Author: Press Plugin Play
*/

include 'ppp-my-favorites.php';
add_action('admin_enqueue_scripts', 'ppp_add_enhanced_ui_scripts', 5); // Lower priority to load earlier
function ppp_add_enhanced_ui_scripts() {
    $screen = get_current_screen();

    // Only load scripts and styles on plugin installation page
    if ($screen && $screen->id === 'plugin-install') {
        wp_enqueue_style('ppp-enhanced-ui', plugin_dir_url(__FILE__) . 'ppp-enhanced-ui.css', array(), '1.5.0');
        wp_enqueue_script('jquery');
        wp_enqueue_script('ppp-custom-filters', plugin_dir_url(__FILE__) . 'ppp-custom-filters.js', array('jquery'), '1.5.0', true);

        // Get the OAuth token and pass it to JavaScript
        $token = 'ok';
        wp_localize_script('ppp-custom-filters', 'pppFiltersData', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'filters' => plugin_dir_url(__FILE__) . 'filters.json',
            'oauth_token' => $token // Pass the token here
        ));
    }
}

add_action('admin_head', 'ppp_inline_styles', 5); // Inject inline styles as early as possible



// Get OAuth 2.0 token from Google Cloud
//$token = getOAuthTokenFromGoogleCloud();




function ppp_inline_styles() {
    $screen = get_current_screen();
    if ($screen && $screen->id === 'plugin-install') {
        echo '<style>
            .plugin-install-recommended { display: none !important; }
            .plugin-recommendation-engine.rec-button a {
                background-color: #0085ba;
                color: #fff;
                font-weight: bold;
                padding: 5px 15px;
                border-radius: 3px;
                text-decoration: none;
                transition: background-color 0.3s ease;
                margin-left: 5px;
            }
            .plugin-recommendation-engine.rec-button a:hover {
                background-color: #005177;
            }
            .ppp-recommendations-container {
                background: #f9f9f9;
                border: 1px solid #ddd;
                border-radius: 4px;
                margin-top: 20px;
                display: flex;
                flex-wrap: wrap;
                width: 100%;
            }
            .ppp-recommendations-form, .ppp-recommendations-results {
                flex: 1;
                padding: 20px;
            }
            .ppp-recommendations-form {
                border-right: 1px solid #ddd;
            }
            .ppp-recommendations-form input,
            .ppp-recommendations-form label {
                display: block;
                margin-bottom: 10px;
                width: 100%;
            }
            .ppp-recommendations-form button {
                background-color: #0085ba;
                color: #fff;
                border: none;
                padding: 10px 15px;
                border-radius: 3px;
                cursor: pointer;
                transition: background-color 0.3s ease;
            }
            .ppp-recommendations-form button:hover {
                background-color: #005177;
            }
            /* Styles for custom dropdown filters */
            .multi-select-container {
                position: relative;
                width: 100%;
                margin-bottom: 10px;
            }
            .search-wrapper {
                display: flex;
                align-items: center;
                position: relative;
            }
            .multi-select-search {
                width: 100%;
                padding: 5px;
            }
            .caret {
                position: absolute;
                right: 10px;
                top: 50%;
                transform: translateY(-50%);
                cursor: pointer;
            }
            .caret-img {
                width: 12px;
                height: 12px;
            }
            .checkbox-container {
                border: 1px solid #ccc;
                max-height: 200px;
                overflow-y: auto;
                background-color: #fff;
                position: absolute;
                width: 100%;
                z-index: 1;
                display: none;
            }
            .checkbox-container label {
                display: block;
                padding: 5px;
            }
            .checkbox-container label:hover {
                background-color: #f1f1f1;
            }
        </style>';
    }
}

add_action('admin_footer', 'ppp_add_custom_ui', 5); // Run earlier to catch initial rendering

function ppp_add_custom_ui() {
    $screen = get_current_screen();

    if ($screen && $screen->id === 'plugin-install') {
        ?>
        <style type="text/css">
            /* Hide the existing search input */
            #search-plugins {
                display: none;
            }
            /* Hide the existing search button if it exists */
            #search-submit {
                display: none;
            }
.rec-button a {
    background-color: #0085ba;
    color: #fff;
    font-weight: bold;
    padding: 5px 15px;
    border-radius: 3px;
    text-decoration: none;
    transition: background-color 0.3s ease;
}

.rec-button a:hover {
    background-color: #005177;
}

.ppp-recommendations-container {
    background: #f9f9f9;
    border: 1px solid #ddd;
    border-radius: 4px;
    margin-top: 20px;
}

.ppp-recommendations-form input,
.ppp-recommendations-form label {
    display: block;
    margin-bottom: 10px;
    width: 100%;
}

.ppp-recommendations-form button {
    background-color: #0085ba;
    color: #fff;
    border: none;
    padding: 10px 15px;
    border-radius: 3px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.ppp-recommendations-form button:hover {
    background-color: #005177;
}


.plugin-favorite-button {
    display: inline-block;
    width: 20px;
    height: 20px;
    border: 2px solid black;
    border-radius: 50%;
    background-color: white;
    text-align: center;
    line-height: 16px;
    font-size: 16px;
    cursor: pointer;
    color: black;
}

.plugin-favorite-button.added {
    background-color: #0085ba;
    border-color: #0085ba;
    color: white;
}


.multi-select-container {
    position: relative;
    width: 100%;
}

.search-wrapper {
    display: flex;
    align-items: center;
}

.multi-select-search {
    width: 100%;
    padding: 5px;
}

.caret {
    cursor: pointer;
}

.checkbox-container {
    border: 1px solid #ccc;
    max-height: 200px;
    overflow-y: auto;
    background-color: #fff;
    position: absolute;
    width: 100%;
    z-index: 1;
}

.checkbox-container label {
    display: block;
    padding: 5px;
}

        </style>
        <script type="text/javascript">
        jQuery(document).ready(function($) {

            // Function to hide the default recommended tab and insert custom button
            function addRecommendationButton() {
                // Hide the default recommended tab
                var recommendedTab = $('.plugin-install-recommended');
                if (recommendedTab.length) {
                    recommendedTab.hide();
                }

                // Add the new recommendation button if not already present
                if ($('.plugin-recommendation-engine').length === 0) {
                    var recButton = $('<li class="plugin-recommendation-engine rec-button"><a href="<?php echo admin_url('plugin-install.php?tab=recommended'); ?>">Recommended Just for You</a></li>');
                    $('.filter-links').append(recButton);
                }
            }

            // Function to add "Try Demo" links
            function addTryDemoLinks() {
                $('.plugin-action-buttons .install-now').each(function() {
                    var installButton = $(this);
                    var slug = installButton.data('slug');

                    // Check if the "Try Demo" link already exists to avoid duplicates
                    if (installButton.closest('ul.plugin-action-buttons').find('.try-demo-link').length === 0 && slug) {
                        // Create the new "Try Demo" link
                        var demoLink = $('<li class="try-demo-link"><a class="button" href="https://presspluginplay.com/' + slug + '" target="_blank" rel="noopener noreferrer">Try Demo</a></li>');

                        // Prepend the "Try Demo" link before the "Install Now" button
                        installButton.closest('ul.plugin-action-buttons').prepend(demoLink);
                    }
                });
            }

            // Function to create and insert the new search form
            function addCustomSearchForm() {
                // Remove the existing search form
                $('#plugin-filter .search-form').remove();

                // Create a new search form
                var customSearchForm = $('<form id="ppp-custom-search-form" method="get" action="<?php echo admin_url('plugin-install.php'); ?>"></form>');

                // Add hidden input fields for required query parameters
                customSearchForm.append('<input type="hidden" name="tab" value="search">');
                customSearchForm.append('<input type="hidden" name="type" value="term">');

                // Add the search input field
                customSearchForm.append('<input type="search" name="s" id="ppp-search-plugins" placeholder="Search Plugins..." style="width: 300px; margin-right: 5px;">');

                // Add the submit button
                customSearchForm.append('<input type="submit" id="ppp-search-submit" class="button" value="Search Plugins">');

                // Insert the custom search form into the page
                $('.wp-filter').append(customSearchForm);
            }

            // Initial run
            addRecommendationButton();
            addTryDemoLinks();
            addCustomSearchForm();

        });
        </script>
        <?php
    }
}



add_action('install_plugins_recommended', 'ppp_render_recommendations_page');

function ppp_render_recommendations_page() {
    ?>
    <div class="ppp-recommendations-container">
        <div class="ppp-recommendations-form">
            <h2>Get Plugin Recommendations Just for You</h2>
            <p>Fill in your details below, and we'll recommend plugins tailored to your needs.</p>
            <form id="ppp-recommendations-form">
                <!-- Skill Level -->
                <label for="skill-level-filter">Skill Level:</label>
                <!-- Custom dropdown filter -->
                <div id="skill-level-filter"></div>

                <!-- Industry -->
                <label for="industry-filter">Industry:</label>
                <!-- Custom dropdown filter -->
                <div id="industry-filter"></div>

                <!-- Niche -->
                <label for="niche-filter">Niche:</label>
                <!-- Custom dropdown filter -->
                <div id="niche-filter"></div>

                <!-- Features Needed -->
                <label for="features-filter">Features Needed:</label>
                <!-- Custom dropdown filter -->
                <div id="features-filter"></div>

                <!-- Integrations -->
                <label for="integrations-filter">Integrations:</label>
                <!-- Custom dropdown filter -->
                <div id="integrations-filter"></div>

                <!-- Plugins You're Already Using -->
                <label for="existing-plugins-filter">Plugins You're Already Using:</label>
                <!-- Custom dropdown filter -->
                <div id="existing-plugins-filter"></div>

                <!-- Your Theme -->
                <label for="ppp-theme">Your Theme:</label>
                <input type="text" id="ppp-theme" name="theme" placeholder="e.g., Divi, Astra" required />

                <!-- Pricing Preference -->
                <label for="pricing-filter">Pricing Preference:</label>
                <!-- Custom dropdown filter -->
                <div id="pricing-filter"></div>

                <!-- Consent Checkbox -->
                <label for="ppp-consent">
                    <input type="checkbox" id="ppp-consent" name="consent" required />
                    I understand this is an experimental feature. My information will be collected and used solely for recommending suitable plugins. Data is secured and completely anonymous.
                </label>

                <button type="submit" class="button button-primary">Get Recommendations</button>
            </form>
        </div>
        <div class="ppp-recommendations-results">
            <h2>Your Recommendations Will Appear Here</h2>
            <p>Fill out the form to see a list of plugins tailored just for you.</p>
            <ul id="ppp-recommendations-list"></ul>
        </div>
    </div>

    <?php
    // Include JavaScript code to handle the form and dropdown filters
    <script>
jQuery(document).ready(function($) {
    $('#ppp-recommendations-form').on('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission

        // Collect data from the form fields
        const formData = {
            skillLevel: $('#skill-level-filter').text(),
            industry: $('#industry-filter').text(),
            niche: $('#niche-filter').text(),
            features: $('#features-filter').text(),
            integrations: $('#integrations-filter').text(),
            existingPlugins: $('#existing-plugins-filter').text(),
            theme: $('#ppp-theme').val(),
            pricingPreference: $('#pricing-filter').text(),
            consent: $('#ppp-consent').is(':checked')
        };
		const token = pppFiltersData.oauth_token;
		
        fetch('https://us-central1-ppbp-436014.cloudfunctions.net/recengine', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify(formData)
                });
            })
            .then(response => response.json())
            .then(data => {
                // Handle the response and display the recommendations
                $('#ppp-recommendations-list').html(
                    data.recommendations.split('\n').map(item => `<li>${item}</li>`).join('')
                );
            })
            .catch(error => {
                console.error('Error:', error);
                $('#ppp-recommendations-list').html('<li>Failed to get recommendations. Please try again later.</li>');
            });
    });
});


jQuery(document).ready(function($) {
    // Use MutationObserver to detect when the plugin list is ready
    var targetNode = document.querySelector('.filter-links');

    if (targetNode) {
        var observer = new MutationObserver(function(mutationsList, observer) {
            // Hide the default recommended tab
            $('.plugin-install-recommended').hide();

            // Append the new recommendation button if it hasn't been added already
            if ($('.plugin-recommendation-engine').length === 0) {
                var recButton = $('<li class="plugin-recommendation-engine rec-button"><a href="/wp-admin/plugin-install.php?tab=recommended">Recommended Just for You</a></li>');
                $('.filter-links').append(recButton);
            }

            // Stop observing once the button is added
            observer.disconnect();
        });

        // Start observing the target node for changes
        observer.observe(targetNode, { childList: true, subtree: true });
    }

    // Use MutationObserver to detect when plugin action buttons are ready
    var pluginListNode = document.querySelector('#the-list');
    if (pluginListNode) {
        var actionObserver = new MutationObserver(function(mutationsList, observer) {
            $('.plugin-action-buttons .install-now').each(function() {
                var installButton = $(this);
                var slug = installButton.data('slug');

                // Check if the "Try Demo" link already exists to avoid duplicates
                if (installButton.closest('ul.plugin-action-buttons').find('.try-demo-link').length === 0) {
                    // Create the new "Try Demo" link
                    var demoLink = $('<li class="try-demo-link"><a class="button" href="https://presspluginplay.com/demo/' + slug + '" target="_blank" rel="noopener noreferrer">Try Demo</a></li>');

                    // Prepend the "Try Demo" link before the "Install Now" button
                    installButton.closest('ul.plugin-action-buttons').prepend(demoLink);
                }
            });

            // Stop observing once the links have been added
            observer.disconnect();
        });

        // Start observing the plugin list for changes
        actionObserver.observe(pluginListNode, { childList: true, subtree: true });
    }
});


    </script>
    
    
    
    
    
    ?>
 
    <?php
}

