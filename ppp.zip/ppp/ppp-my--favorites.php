<?php
/*
 * Adds custom functionality to enhance the "Favorites" tab, including a personalized
 * favorites list and a favorite button for each plugin card.
 */

add_action('admin_enqueue_scripts', 'ppp_favorites_enqueue_scripts', 5);

function ppp_favorites_enqueue_scripts() {
    $screen = get_current_screen();

    // Only load script and style on plugin installation page
    if ($screen && $screen->id === 'plugin-install') {
        wp_enqueue_style('ppp-favorites-ui', plugin_dir_url(__FILE__) . 'ppp-favorites-ui.css', array(), '1.0.0');
        wp_enqueue_script('ppp-favorites-ui', plugin_dir_url(__FILE__) . 'ppp-favorites-ui.js', array('jquery'), '1.0.0', true);
    }
}

add_action('admin_head', 'ppp_favorites_inline_styles', 5);

function ppp_favorites_inline_styles() {
    $screen = get_current_screen();
    if ($screen && $screen->id === 'plugin-install') {
        echo '<style>
            .plugin-install-favorites { display: none !important; }
            .plugin-favorite-button {
                display: inline-block;
                width: 20px;
                height: 20px;
                border: 2px solid black;
                border-radius: 50%;
                background-color: white;
                text-align: center;
                line-height: 16px;
                font-size: 16px;
                cursor: pointer;
                color: black;
            }
            .plugin-favorite-button.added {
                background-color: #0085ba;
                border-color: #0085ba;
                color: white;
            }
            .ppp-my-favorites-container {
                display: flex;
                flex-wrap: wrap;
                gap: 20px;
                padding: 20px;
                background: #f9f9f9;
                border: 1px solid #ddd;
                border-radius: 4px;
                margin-bottom: 20px;
            }
        </style>';
    }
}

add_action('admin_footer', 'ppp_add_favorites_ui', 5);

function ppp_add_favorites_ui() {
    $screen = get_current_screen();

    if ($screen && $screen->id === 'plugin-install') {
        ?>
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            // Hide the native "Favorites" tab content and add the custom favorites section
            $('.plugin-install-favorites').hide();

            if ($('.plugin-my-favorites').length === 0) {
                var myFavoritesButton = $('<li class="plugin-my-favorites rec-button"><a href="/wp-admin/plugin-install.php?tab=favorites">My Favorites</a></li>');
                $('.filter-links').append(myFavoritesButton);
            }

            // Add "Add to Favorites" buttons to each plugin card
            function addFavoriteButtons() {
                $('.plugin-action-buttons').each(function() {
                    var actionButtons = $(this);
                    var installButton = actionButtons.find('.install-now');
                    var slug = installButton.data('slug');

                    // Create the favorite button
                    var favoriteButton = $('<div class="plugin-favorite-button" data-slug="' + slug + '">+</div>');

                    // Check if the plugin is already in the favorites list
                    var favoritesList = JSON.parse(localStorage.getItem('pppFavoritesList') || '[]');
                    if (favoritesList.includes(slug)) {
                        favoriteButton.addClass('added').text('-');
                    }

                    // Prepend the favorite button directly to the <ul> where the install and try demo links are
                    actionButtons.prepend(favoriteButton);

                    // Toggle favorite status on click
                    favoriteButton.on('click', function() {
                        var slug = $(this).data('slug');
                        var favorites = JSON.parse(localStorage.getItem('pppFavoritesList') || '[]');

                        if (favorites.includes(slug)) {
                            // Remove from favorites
                            favorites = favorites.filter(function(item) { return item !== slug; });
                            $(this).removeClass('added').text('+');
                        } else {
                            // Add to favorites
                            favorites.push(slug);
                            $(this).addClass('added').text('-');
                        }

                        // Update the favorites list in localStorage
                        localStorage.setItem('pppFavoritesList', JSON.stringify(favorites));
                    });
                });
            }

            // Run the function immediately and then again in case of delayed elements
            addFavoriteButtons();
            setTimeout(addFavoriteButtons, 500);

            // Inject custom favorites list above the content when in the "Favorites" tab
            function loadFavorites() {
                var favorites = JSON.parse(localStorage.getItem('pppFavoritesList') || '[]');
                var favoritesListContainer = $('<div class="ppp-my-favorites-container"><h2>My Favorite Plugins</h2><div id="ppp-favorites-list"></div></div>');
                
                if (favorites.length === 0) {
                    favoritesListContainer.find('#ppp-favorites-list').html('<p>No favorite plugins added yet.</p>');
                } else {
                    var favoritesList = $('<div style="display: flex; flex-wrap: wrap; gap: 10px;"></div>');
                    
                    favorites.forEach(function(slug) {
                        var pluginCard = $(
                            '<div class="plugin-card" style="width: 300px; border: 1px solid #ddd; padding: 10px; border-radius: 4px;">' +
                                '<h3>' + slug + '</h3>' +
                                '<div class="plugin-actions">' +
                                    '<a class="button" href="https://presspluginplay.com/demo/' + slug + '" target="_blank">Try Demo</a>' +
                                    '<a class="button" href="/wp-admin/plugin-install.php?tab=plugin-information&plugin=' + slug + '&TB_iframe=true&width=600&height=550" class="thickbox">Learn More</a>' +
                                '</div>' +
                            '</div>'
                        );
                        favoritesList.append(pluginCard);
                    });

                    favoritesListContainer.find('#ppp-favorites-list').html(favoritesList);
                }

                // Inject above the main content of the favorites tab
                $('#plugin-information').before(favoritesListContainer);
            }

            // Load favorites if the "Favorites" tab is active
            if (window.location.search.includes('tab=favorites')) {
                loadFavorites();
            }
        });
        </script>
        <?php
    }
}
?>

