<?php
/*
// Check if the request is an AJAX request
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') {
     //header('HTTP/1.0 404');
    include 'error.html';
    exit();
}
 */


function getOAuthTokenFromGoogleCloud($jsonKeyPath) {
    if (!file_exists($jsonKeyPath)) {
        return null; // Handle missing file error
    }

    // Read the service account JSON file
    $jsonData = file_get_contents($jsonKeyPath);
    $credentials = json_decode($jsonData, true);

    if ($credentials === null) {
        // JSON parse error
        echo json_last_error_msg();
        return null;
    }

    // Extract necessary information from JSON
    $privateKey = $credentials['private_key'];
    $clientEmail = $credentials['client_email'];
    $tokenUrl = $credentials['token_uri'];

    // JWT claim set for the token
    $now = time();
    $expires = $now + 600; // Token expires in 1 hour

    $jwtHeader = json_encode([
        'alg' => 'RS256',
        'typ' => 'JWT'
    ]);

    $jwtPayload = json_encode([
        'iss' => $clientEmail,          // Issuer
        'scope' => 'https://www.googleapis.com/auth/cloud-platform',  // Scopes for your API access
        'aud' => $tokenUrl,             // Audience
        'iat' => $now,                  // Issued at
        'exp' => $expires               // Expiration time
    ]);

    // Base64 encode header and payload
    $jwtBase64Header = rtrim(strtr(base64_encode($jwtHeader), '+/', '-_'), '=');
    $jwtBase64Payload = rtrim(strtr(base64_encode($jwtPayload), '+/', '-_'), '=');

    // Concatenate the header and payload with a dot
    $unsignedToken = $jwtBase64Header . '.' . $jwtBase64Payload;

    // Sign the token with the private key using RS256
    $signature = '';
    if (!openssl_sign($unsignedToken, $signature, $privateKey, 'SHA256')) {
        // Handle signing errors
        echo 'Error signing JWT';
        return null;
    }

    // Base64 encode the signature and concatenate it to the unsigned token
    $jwtSignature = rtrim(strtr(base64_encode($signature), '+/', '-_'), '=');
    $signedJwt = $unsignedToken . '.' . $jwtSignature;

    // Request an OAuth token using the JWT
    $postData = http_build_query([
        'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        'assertion' => $signedJwt
    ]);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $tokenUrl);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Execute the request and check for curl errors
    $response = curl_exec($ch);
    if ($response === false) {
        echo 'Curl error: ' . curl_error($ch);
        curl_close($ch);
        return null;
    }
    curl_close($ch);

    // Parse the response and return the token
    $responseData = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        // Handle JSON parse error
        echo 'JSON decode error: ' . json_last_error_msg();
        echo 'Response: ' . $response;
        return null;
    }

    if (isset($responseData['access_token'])) {
        return $responseData['access_token'];
    } else {
        echo 'Error fetching token: ' . $response;
        return null; // Handle case where access_token is missing
    }
}

// Path to your service account JSON key
$jsonKeyPath = '/etc/google-cloud/ppbp-436014-bfecd35cf1b3.json';

// Get OAuth 2.0 token from Google Cloud
$token = getOAuthTokenFromGoogleCloud($jsonKeyPath);

if ($token) {
    // Return the token as JSON
    header('Content-Type: application/json');
    echo json_encode(['token' => $token]);
} else {
    // Handle error if token generation fails
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(['error' => 'Failed to generate token']);
}

//$output = shell_exec("node upload.js");

// Process the output from tokenHandler.py (e.g., the generated token)
//echo $output;

?>

