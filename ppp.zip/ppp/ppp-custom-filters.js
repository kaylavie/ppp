// ppp-custom-filters.js
jQuery(document).ready(function($) {
    // Load filters from filters.json and create dropdowns
    $.getJSON(pppFiltersData.filters, function(filters) {
        createFilterDropdown(filters.skillLevels, 'Skill Level', 'skillLevel', 'skill-level-filter');
        createFilterDropdown(filters.industries, 'Industry', 'industry', 'industry-filter');
        createFilterDropdown(filters.niches, 'Niche', 'niche', 'niche-filter');
        createFilterDropdown(filters.features, 'Features Needed', 'features', 'features-filter');
        createFilterDropdown(filters.integrations, 'Integrations', 'integrations', 'integrations-filter');
        createFilterDropdown(filters.existingPlugins, 'Plugins You\'re Already Using', 'existingPlugins', 'existing-plugins-filter');
        createFilterDropdown(filters.pricingOptions, 'Pricing Preference', 'pricing', 'pricing-filter');
    });
    
    
    
/*
    // Form submission handler
    $('#ppp-recommendations-form').on('submit', function(event) {
        event.preventDefault();

        // Collect selected values
        var formData = {
            skillLevel: getSelectedValues('skillLevel'),
            industry: getSelectedValues('industry'),
            niche: getSelectedValues('niche'),
            features: getSelectedValues('features'),
            integrations: getSelectedValues('integrations'),
            existingPlugins: getSelectedValues('existingPlugins'),
            pricing: getSelectedValues('pricing'),
            theme: $('#ppp-theme').val(),
            consent: $('#ppp-consent').is(':checked')
        };

        // Simulate a recommendation fetch - replace with AJAX call in production
        $('#ppp-recommendations-list').html('<li>Loading recommendations...</li>');

        // Simulate an AJAX call to fetch recommendations
        setTimeout(function() {
            $('#ppp-recommendations-list').html(
                '<li><strong>Plugin A:</strong> A great SEO plugin for your skill level and industry.</li>' +
                '<li><strong>Plugin B:</strong> An integration plugin matching your selected features.</li>' +
                '<li><strong>Plugin C:</strong> Custom Forms plugin compatible with your theme.</li>'
            );
        }, 1000);
    });
*/

    // Function to create custom dropdown filters
    function createFilterDropdown(options, label, filterName, selectId) {
        var container = $('<div>').addClass('multi-select-container');

        // Get the number of options
        var optionCount = options.length;

        // Create search input with a caret and display the option count
        var searchInput = $('<div class="search-wrapper">' +
            '<input type="text" id="multi-select-search-' + selectId + '" placeholder="Search ' + label + ' (' + optionCount + ' options)..." class="multi-select-search" onfocus="focusOptions(\'' + selectId + '\')" onkeyup="filterOptions(\'' + selectId + '\')">' +
            '<span class="caret" onclick="toggleOptions(\'' + selectId + '\')">' +
            '<img src="https://www.svgrepo.com/show/361708/caret-down.svg" class="caret-img">' +
            '</span>' +
            '</div>');

        container.append(searchInput);

        // Create container for checkboxes (initially hidden)
        var checkboxContainer = $('<div id="multi-select-options-' + selectId + '" class="checkbox-container multi-select-options"></div>');

        // Add checkboxes for each option
        $.each(options, function(index, option) {
            checkboxContainer.append(
                '<label><input type="checkbox" value="' + option + '" name="' + filterName + '"> ' + option.charAt(0).toUpperCase() + option.slice(1) + '</label>'
            );
        });

        container.append(checkboxContainer);
        $('#' + selectId).append(container);  // Append the container to the corresponding div in the form
    }

    // Helper functions for dropdown behavior
    window.toggleOptions = function(selectId) {
        $('#multi-select-options-' + selectId).toggle();
    }

    window.focusOptions = function(selectId) {
        $('#multi-select-options-' + selectId).show();
    }

    window.filterOptions = function(selectId) {
        var input = $('#multi-select-search-' + selectId).val().toLowerCase();
        $('#multi-select-options-' + selectId + ' label').filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(input) > -1)
        });
    }

    // Function to get selected values from multi-select checkboxes
    function getSelectedValues(filterName) {
        return $('input[name="' + filterName + '"]:checked').map(function() {
            return this.value;
        }).get();
    }
});








jQuery(document).ready(function($) {
    $('#ppp-recommendations-form').on('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission

        // Collect data from the form fields
        const formData = {
            skillLevel: $('#skill-level-filter').text(),
            industry: $('#industry-filter').text(),
            niche: $('#niche-filter').text(),
            features: $('#features-filter').text(),
            integrations: $('#integrations-filter').text(),
            existingPlugins: $('#existing-plugins-filter').text(),
            theme: $('#ppp-theme').val(),
            pricingPreference: $('#pricing-filter').text(),
            consent: $('#ppp-consent').is(':checked')
        };

        console.log('Form Data:', formData);
        console.log('OAuth Token:', pppFiltersData.oauth_token);
        
        // Make the fetch request
        fetch('https://us-central1-ppbp-436014.cloudfunctions.net/recengine', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${pppFiltersData.oauth_token}`,
                mode: 'cors'
            },
            body: JSON.stringify(formData)
        })
        .then(response => {
            if (!response.ok) {
                // Handle non-2xx responses as errors
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            // Handle the response and display the recommendations
            $('#ppp-recommendations-list').html(
                data.recommendations.split('\n').map(item => `<li>${item}</li>`).join('')
            );
        })
        .catch(error => {
            console.error('Error:', error);
            $('#ppp-recommendations-list').html('<li>Failed to get recommendations. Please try again later.</li>');
        });
    });
});



