(function($) {
    $(document).ready(function() {

        // Helper log function
        function log(message) {
            if (window.ppp_debug) console.log('PPPlayground:', message);
        }

        // Add "Try Demo" links next to each plugin install button
        function addTryDemoLinks() {
            $('.plugin-action-buttons .install-now').each(function() {
                const installButton = $(this);
                const slug = installButton.data('slug');
                if (!installButton.siblings('.try-demo-link').length && slug) {
                    const demoLink = $('<li class="try-demo-link"><a class="button" href="https://presspluginplay.com/' + slug + '" target="_blank" rel="noopener noreferrer">Try Demo</a></li>');
                    installButton.before(demoLink);
                    log(`Added Try Demo link for slug: ${slug}`);
                }
            });
        }

        // Add a custom search form to replace the original
        function addCustomSearchForm() {
            // Remove any existing custom search form
            $('#ppp-custom-search-form').remove();

            // Create new form
            const customSearchForm = $('<form id="ppp-custom-search-form" method="get" action="' + ppp_data.pluginInstallUrl + '"></form>');

            // Form inputs
            customSearchForm.append(`
                <input type="hidden" name="tab" value="search">
                <input type="hidden" name="type" value="term">
                <input type="search" name="s" placeholder="Search Plugins..." style="width: 300px; margin-right: 5px;">
                <input type="submit" class="button" value="Search Plugins">
            `);

            // Append to .wp-filter
            $('.wp-filter').append(customSearchForm);
            log('Custom search form added.');
        }

        // Hide the original search form permanently
        function hideOriginalSearchForm() {
            $('.wp-filter .search-form').remove();
        }

        // Insert custom UI elements (hide original search, add demo links, custom search form)
        function insertCustomUI() {
            hideOriginalSearchForm();
            addTryDemoLinks();
            addCustomSearchForm();
            $('#plugin-filter').css('opacity', '1'); // Reveal plugin area after loading custom UI
        }

        // Initialize UI insertion, with MutationObserver backup
        function initCustomUI() {
            if ($('.filter-links').length && $('.plugin-action-buttons').length && $('.wp-filter').length) {
                insertCustomUI();
            } else {
                // Observe DOM changes until elements are ready
                const observer = new MutationObserver(function(mutations, obs) {
                    mutations.forEach(function(mutation) {
                        mutation.addedNodes.forEach(function(node) {
                            if (node.nodeType === 1 && (node.querySelector('.filter-links') || node.querySelector('.plugin-action-buttons') || node.querySelector('.wp-filter'))) {
                                if ($('.filter-links').length && $('.plugin-action-buttons').length && $('.wp-filter').length) {
                                    insertCustomUI();
                                    obs.disconnect();
                                }
                            }
                        });
                    });
                });
                observer.observe(document.body, { childList: true, subtree: true });
                log('Started MutationObserver as backup.');
            }
        }

        // Re-hide the original search form after any AJAX updates
        $(document).ajaxComplete(hideOriginalSearchForm);

        // Set debugging mode
        window.ppp_debug = true;
        initCustomUI();

    });
})(jQuery);

