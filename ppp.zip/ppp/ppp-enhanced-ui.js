
jQuery(document).ready(function($) {
    

    // Use MutationObserver to detect when plugin action buttons are ready
    var pluginListNode = document.querySelector('#the-list');
    if (pluginListNode) {
        var actionObserver = new MutationObserver(function(mutationsList, observer) {
            $('.plugin-action-buttons .install-now').each(function() {
                var installButton = $(this);
                var slug = installButton.data('slug');

                // Check if the "Try Demo" link already exists to avoid duplicates
                if (installButton.closest('ul.plugin-action-buttons').find('.try-demo-link').length === 0) {
                    // Create the new "Try Demo" link
                    var demoLink = $('<li class="try-demo-link"><a class="button" href="https://presspluginplay.com/demo/' + slug + '" target="_blank" rel="noopener noreferrer">Try Demo</a></li>');

                    // Prepend the "Try Demo" link before the "Install Now" button
                    installButton.closest('ul.plugin-action-buttons').prepend(demoLink);
                }
            });

            // Stop observing once the links have been added
            observer.disconnect();
        });

        // Start observing the plugin list for changes
        actionObserver.observe(pluginListNode, { childList: true, subtree: true });
    }
});


