<?php
/*
Plugin Name: Demo WordPress Plugins
Description: Adds a "Try Demo" button to each plugin card in the WordPress admin dashboard, enhances search functionality, and provides personalized plugin recommendations.
Version: 1.5.0
Author: Press Plugin Play
*/



add_action('admin_head', 'ppp_inline_styles', 5); 




function ppp_inline_styles() {
    $screen = get_current_screen();
    if ($screen && $screen->id === 'plugin-install') {
        echo '<style>
          
            .search-wrapper {
                display: flex;
                align-items: center;
                position: relative;
            }
            .multi-select-search {
                width: 100%;
                padding: 5px;
            }
            .caret {
                position: absolute;
                right: 10px;
                top: 50%;
                transform: translateY(-50%);
                cursor: pointer;
            }
            .caret-img {
                width: 12px;
                height: 12px;
            }
            .checkbox-container {
                border: 1px solid #ccc;
                max-height: 200px;
                overflow-y: auto;
                background-color: #fff;
                position: absolute;
                width: 100%;
                z-index: 1;
                display: none;
            }
            .checkbox-container label {
                display: block;
                padding: 5px;
            }
            .checkbox-container label:hover {
                background-color: #f1f1f1;
            }
        </style>';
    }
}

add_action('admin_footer', 'ppp_add_custom_ui', 5); // Run earlier to catch initial rendering

function ppp_add_custom_ui() {
    $screen = get_current_screen();

    if ($screen && $screen->id === 'plugin-install') {
        ?>
        <style type="text/css">
            /* Hide the existing search input */
            #search-plugins {
                display: none;
            }
            /* Hide the existing search button if it exists */
            #search-submit {
                display: none;
            }
        </style>
        <script type="text/javascript">
        jQuery(document).ready(function($) {

           

            // Function to add "Try Demo" links
            function addTryDemoLinks() {
                $('.plugin-action-buttons .install-now').each(function() {
                    var installButton = $(this);
                    var slug = installButton.data('slug');

                    // Check if the "Try Demo" link already exists to avoid duplicates
                    if (installButton.closest('ul.plugin-action-buttons').find('.try-demo-link').length === 0 && slug) {
                        // Create the new "Try Demo" link
                        var demoLink = $('<li class="try-demo-link"><a class="button" href="https://presspluginplay.com/' + slug + '" target="_blank" rel="noopener noreferrer">Try Demo</a></li>');

                        // Prepend the "Try Demo" link before the "Install Now" button
                        installButton.closest('ul.plugin-action-buttons').prepend(demoLink);
                    }
                });
            }

            // Function to create and insert the new search form
            function addCustomSearchForm() {
                // Remove the existing search form
                $('#plugin-filter .search-form').remove();

                // Create a new search form
                var customSearchForm = $('<form id="ppp-custom-search-form" method="get" action="<?php echo admin_url('plugin-install.php'); ?>"></form>');

                // Add hidden input fields for required query parameters
                customSearchForm.append('<input type="hidden" name="tab" value="search">');
                customSearchForm.append('<input type="hidden" name="type" value="term">');

                // Add the search input field
                customSearchForm.append('<input type="search" name="s" id="ppp-search-plugins" placeholder="Search Plugins..." style="width: 300px; margin-right: 5px;">');

                // Add the submit button
                customSearchForm.append('<input type="submit" id="ppp-search-submit" class="button" value="Search Plugins">');

                // Insert the custom search form into the page
                $('.wp-filter').append(customSearchForm);
            }

            // Initial run

            addTryDemoLinks();
            addCustomSearchForm();

        });
        </script>
        <?php
    }
}



add_action('install_plugins_recommended', 'ppp_render_recommendations_page');

function ppp_render_recommendations_page() {
    ?>
    <div class="ppp-recommendations-container">
        <div class="ppp-recommendations-form">
            <h2>Get Plugin Recommendations Just for You</h2>
            <p>Fill in your details below, and we'll recommend plugins tailored to your needs.</p>
            <form id="ppp-recommendations-form">
                <!-- Skill Level -->
                <label for="skill-level-filter">Skill Level:</label>
                <!-- Custom dropdown filter -->
                <div id="skill-level-filter"></div>

                <!-- Industry -->
                <label for="industry-filter">Industry:</label>
                <!-- Custom dropdown filter -->
                <div id="industry-filter"></div>

                <!-- Niche -->
                <label for="niche-filter">Niche:</label>
                <!-- Custom dropdown filter -->
                <div id="niche-filter"></div>

                <!-- Features Needed -->
                <label for="features-filter">Features Needed:</label>
                <!-- Custom dropdown filter -->
                <div id="features-filter"></div>

                <!-- Integrations -->
                <label for="integrations-filter">Integrations:</label>
                <!-- Custom dropdown filter -->
                <div id="integrations-filter"></div>

                <!-- Plugins You're Already Using -->
                <label for="existing-plugins-filter">Plugins You're Already Using:</label>
                <!-- Custom dropdown filter -->
                <div id="existing-plugins-filter"></div>

                <!-- Your Theme -->
                <label for="ppp-theme">Your Theme:</label>
                <input type="text" id="ppp-theme" name="theme" placeholder="e.g., Divi, Astra" required />

                <!-- Pricing Preference -->
                <label for="pricing-filter">Pricing Preference:</label>
                <!-- Custom dropdown filter -->
                <div id="pricing-filter"></div>

                <!-- Consent Checkbox -->
                <label for="ppp-consent">
                    <input type="checkbox" id="ppp-consent" name="consent" required />
                    I understand this is an experimental feature. My information will be collected and used solely for recommending suitable plugins. Data is secured and completely anonymous.
                </label>

                <button type="submit" class="button button-primary">Get Recommendations</button>
            </form>
        </div>
        <div class="ppp-recommendations-results">
            <h2>Your Recommendations Will Appear Here</h2>
            <p>Fill out the form to see a list of plugins tailored just for you.</p>
            <ul id="ppp-recommendations-list"></ul>
        </div>
    </div>

    <?php
    // Include JavaScript code to handle the form and dropdown filters
    ?>
 
    <?php
}


